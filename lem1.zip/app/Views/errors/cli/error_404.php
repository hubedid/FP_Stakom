<?php

use CodeIgniter\CLI\CLI;

CLI::error('ERROR nih: ' . $code);
CLI::write($message);
CLI::newLine();
