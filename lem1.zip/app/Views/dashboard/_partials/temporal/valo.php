<!-- Begin Page Content -->
<div class="container-fluid">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h3 class="card-title">Violation Report</h6>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                            <i class="fas fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="card-body">
                        <div class="chart-container" style="position: relative; height:40vh;">
                            <img src="https://cdn.discordapp.com/attachments/699829022934433803/1043519344476434552/image.png" alt="vio" style="position: relative; height:30vh;">
                        </div>
                    </div>
                </div>
            </div>